DEFINITIONS
-----------

For CMake 2.4 compatibility only.  Use COMPILE_DEFINITIONS instead.

This read-only property specifies the list of flags given so far to
the add_definitions command.  It is intended for debugging purposes.
Use the COMPILE_DEFINITIONS instead.
