XCODE_ATTRIBUTE_<an-attribute>
------------------------------

Set Xcode target attributes directly.

Tell the Xcode generator to set '<an-attribute>' to a given value in
the generated Xcode project.  Ignored on other generators.
