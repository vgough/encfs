GENERATOR_FILE_NAME
-------------------

Generator's file for this target.

An internal property used by some generators to record the name of the
project or dsp file associated with this target.  Note that at
configure time, this property is only set for targets created by
include_external_msproject().
