EXCLUDE_FROM_DEFAULT_BUILD
--------------------------

Exclude target from "Build Solution".

This property is only used by Visual Studio generators 7 and above.
When set to TRUE, the target will not be built when you press "Build
Solution".
