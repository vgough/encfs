OUTPUT_NAME_<CONFIG>
--------------------

Per-configuration target file base name.

This is the configuration-specific version of OUTPUT_NAME.
