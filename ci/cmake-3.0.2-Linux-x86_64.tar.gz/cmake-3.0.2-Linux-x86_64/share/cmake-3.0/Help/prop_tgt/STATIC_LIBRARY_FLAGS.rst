STATIC_LIBRARY_FLAGS
--------------------

Extra flags to use when linking static libraries.

Extra flags to use when linking a static library.
