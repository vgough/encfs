VS_WINRT_EXTENSIONS
-------------------

Visual Studio project C++/CX language extensions for Windows Runtime

Can be set to enable C++/CX language extensions.
