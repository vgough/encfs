FRAMEWORK
---------

This target is a framework on the Mac.

If a shared library target has this property set to true it will be
built as a framework when built on the mac.  It will have the
directory structure required for a framework and will be suitable to
be used with the -framework option
