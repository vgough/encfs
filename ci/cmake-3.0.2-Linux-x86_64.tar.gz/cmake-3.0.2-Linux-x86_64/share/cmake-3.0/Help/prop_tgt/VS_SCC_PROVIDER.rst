VS_SCC_PROVIDER
---------------

Visual Studio Source Code Control Provider.

Can be set to change the visual studio source code control provider
property.
