SOURCES
-------

Source names specified for a target.

Read-only list of sources specified for a target.  The names returned
are suitable for passing to the set_source_files_properties command.
