STATIC_LIBRARY_FLAGS_<CONFIG>
-----------------------------

Per-configuration flags for creating a static library.

This is the configuration-specific version of STATIC_LIBRARY_FLAGS.
