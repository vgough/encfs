CMAKE_HOST_SYSTEM_NAME
----------------------

Name of the OS CMake is running on.

The same as CMAKE_SYSTEM_NAME but for the host system instead of the
target system when cross compiling.
