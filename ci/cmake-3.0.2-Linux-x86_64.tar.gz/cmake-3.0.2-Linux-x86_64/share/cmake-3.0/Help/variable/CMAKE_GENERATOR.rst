CMAKE_GENERATOR
---------------

The generator used to build the project.

The name of the generator that is being used to generate the build
files.  (e.g.  "Unix Makefiles", "Visual Studio 6", etc.)
