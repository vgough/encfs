CMAKE_<LANG>_VISIBILITY_PRESET
------------------------------

Default value for <LANG>_VISIBILITY_PRESET of targets.

This variable is used to initialize the <LANG>_VISIBILITY_PRESET
property on all the targets.  See that target property for additional
information.
