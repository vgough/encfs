CMAKE_MAJOR_VERSION
-------------------

First version number component of the :variable:`CMAKE_VERSION`
variable.
