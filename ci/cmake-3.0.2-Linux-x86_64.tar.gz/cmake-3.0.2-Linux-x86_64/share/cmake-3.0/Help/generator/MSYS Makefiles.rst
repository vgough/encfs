MSYS Makefiles
--------------

Generates MSYS makefiles.

The makefiles use /bin/sh as the shell.  They require msys to be
installed on the machine.
