MinGW Makefiles
---------------

Generates a make file for use with mingw32-make.

The makefiles generated use cmd.exe as the shell.  They do not require
msys or a unix shell.
