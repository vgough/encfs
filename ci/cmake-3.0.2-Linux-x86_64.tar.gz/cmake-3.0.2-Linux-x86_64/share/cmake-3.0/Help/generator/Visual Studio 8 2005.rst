Visual Studio 8 2005
--------------------

Generates Visual Studio 8 2005 project files.

It is possible to append a space followed by the platform name to
create project files for a specific target platform.  E.g.  "Visual
Studio 8 2005 Win64" will create project files for the x64 processor.
