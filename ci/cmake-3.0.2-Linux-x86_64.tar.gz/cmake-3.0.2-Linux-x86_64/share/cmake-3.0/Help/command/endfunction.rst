endfunction
-----------

Ends a list of commands in a function block.

::

  endfunction(expression)

See the function command.
