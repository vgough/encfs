FAIL_REGULAR_EXPRESSION
-----------------------

If the output matches this regular expression the test will fail.

If set, if the output matches one of specified regular expressions,
the test will fail.For example: FAIL_REGULAR_EXPRESSION
"[^a-z]Error;ERROR;Failed"
